## Credits
Icons has been generously derived from Icons8. More info can be found below.

<a target="_blank" href="https://icons8.com/icon/ezUTJdV6xvqx/google-sheets">Google Sheets</a> icon by <a target="_blank" href="https://icons8.com">Icons8</a>